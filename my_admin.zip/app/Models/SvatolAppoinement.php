<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SvatolAppoinement extends Model
{
    use HasFactory;
    protected $table = 'svatol_appoinement'; // Link to existing table
}
