<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Profit Square</title>
    <link rel="shortcut icon" href="/favicons/favicon.jpg" />
    <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/react/index.js'); ?>
</head>
<body>
<div id="root"></div>
</body>
</html><?php /**PATH D:\Tipic\Project\Working projects\Profit_Square\resources\views/welcome.blade.php ENDPATH**/ ?>